package aulaHeranca;

public class Fusca extends Carro {
	
	String fusca = "Fusca";

	//@Override
	//void acelerar() {
	//	velocidade += 8;
	//}
	
	@Override
	public String toString() {
		return "A velocidade do " + fusca + " é: " + velocidade;
	}

}