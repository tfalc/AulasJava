package aulaHeranca;

public class UsandoCarro {

	public static void main(String[] args) {

		Carro fusca1 = new Fusca();

		fusca1.acelerar();
		System.out.println(fusca1);

		fusca1.acelerar();
		System.out.println(fusca1);

		fusca1.acelerar();
		System.out.println(fusca1);

		Carro ferrari1 = new Ferrari();

		ferrari1.acelerar();
		System.out.println(ferrari1);
		ferrari1.acelerar();
		System.out.println(ferrari1);
		ferrari1.acelerar();
		System.out.println(ferrari1);
		ferrari1.acelerar();
		System.out.println(ferrari1);
		ferrari1.frear();
		System.out.println(ferrari1);
		ferrari1.frear();
		System.out.println(ferrari1);
		ferrari1.frear();
		System.out.println(ferrari1);
		ferrari1.frear();
		System.out.println(ferrari1);
		ferrari1.frear();
		System.out.println(ferrari1);
	}

}
