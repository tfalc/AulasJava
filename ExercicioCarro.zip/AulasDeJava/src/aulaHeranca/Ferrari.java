package aulaHeranca;

public class Ferrari extends Carro {
	
	String ferrari = "Ferrari";

	@Override
	void acelerar() {
		velocidade += 15;
	}

	@Override
	void frear() {
		if (velocidade >= 15) {
			velocidade -= 15;
		} else {
			velocidade = 0;
		}
	}
	
	@Override
	public String toString() {
		return "A velocidade do " + ferrari + " é: " + velocidade;
	}
}
